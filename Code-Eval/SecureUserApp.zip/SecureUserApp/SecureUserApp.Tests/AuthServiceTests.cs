﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SecureUserApp.Services;

namespace SecureUserApp.Tests
{
    [TestClass]
    public class AuthServiceTests
    {
        // ==============================
        // ✅ Test 1: Register Should Work
        // ==============================
        [TestMethod]
        public void Register_Should_Return_True()
        {
            // Arrange
            AuthService auth = new AuthService();

            // Act
            bool result = auth.Register("test", "123");

            // Assert
            Assert.IsTrue(result);
        }

        // ==============================
        // ✅ Test 2: Login Should Work
        // ==============================
        [TestMethod]
        public void Login_Should_Return_True_When_Correct_Credentials()
        {
            // Arrange
            AuthService auth = new AuthService();
            auth.Register("testuser", "password123");

            // Act
            bool result = auth.Login("testuser", "password123");

            // Assert
            Assert.IsTrue(result);
        }

        // ==============================
        // ❌ Test 3: Login Should Fail
        // ==============================
        [TestMethod]
        public void Login_Should_Return_False_When_Wrong_Password()
        {
            // Arrange
            AuthService auth = new AuthService();
            auth.Register("testuser", "password123");

            // Act
            bool result = auth.Login("testuser", "wrongpassword");

            // Assert
            Assert.IsFalse(result);
        }
    }
}