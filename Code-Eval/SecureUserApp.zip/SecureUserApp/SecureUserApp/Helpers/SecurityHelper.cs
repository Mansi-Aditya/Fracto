﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace SecureUserApp.Helpers
{
    public static class SecurityHelper
    {
        // ================================
        // 🔐 1. SHA-256 Password Hashing
        // ================================
        public static string HashPassword(string password)
        {
            try
            {
                using (SHA256 sha256 = SHA256.Create())
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(password);
                    byte[] hash = sha256.ComputeHash(bytes);

                    StringBuilder builder = new StringBuilder();
                    foreach (byte b in hash)
                    {
                        builder.Append(b.ToString("x2"));
                    }

                    return builder.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error while hashing password", ex);
            }
        }

        // ================================
        // 🔐 2. Generate AES Key
        // ================================
        public static byte[] GenerateKey()
        {
            using (Aes aes = Aes.Create())
            {
                return aes.Key;
            }
        }

        // ================================
        // 🔐 3. Generate AES IV
        // ================================
        public static byte[] GenerateIV()
        {
            using (Aes aes = Aes.Create())
            {
                return aes.IV;
            }
        }

        // ================================
        // 🔐 4. Encrypt Data using AES
        // ================================
        public static byte[] Encrypt(string plainText, byte[] key, byte[] iv)
        {
            try
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Key = key;
                    aes.IV = iv;

                    ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                    byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);

                    return encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error while encrypting data", ex);
            }
        }

        // ================================
        // 🔐 5. Decrypt Data using AES
        // ================================
        public static string Decrypt(byte[] cipherText, byte[] key, byte[] iv)
        {
            try
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Key = key;
                    aes.IV = iv;

                    ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                    byte[] decryptedBytes = decryptor.TransformFinalBlock(cipherText, 0, cipherText.Length);

                    return Encoding.UTF8.GetString(decryptedBytes);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error while decrypting data", ex);
            }
        }
    }
}