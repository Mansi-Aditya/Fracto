﻿using System;
using System.Collections.Generic;
using SecureUserApp.Models;
using SecureUserApp.Helpers;

namespace SecureUserApp.Services
{
    public class AuthService
    {
        private List<User> users = new List<User>();

        public bool Register(string username, string password)
        {
            try
            {
                string hashedPassword = SecurityHelper.HashPassword(password);
                User user = new User(username, hashedPassword);
                users.Add(user);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Login(string username, string password)
        {
            try
            {
                string hashedPassword = SecurityHelper.HashPassword(password);

                foreach (var user in users)
                {
                    if (user.Username == username &&
                        user.HashedPassword == hashedPassword)
                    {
                        return true;
                    }
                }

                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}