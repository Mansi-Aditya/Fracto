﻿using System;
using SecureUserApp.Services;
using Serilog;

namespace SecureUserApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // ===============================
            // 🔹 1. Configure Serilog
            // ===============================
            Log.Logger = new LoggerConfiguration()
                .WriteTo.File("log.txt", rollingInterval: RollingInterval.Day)
                .CreateLogger();

            try
            {
                Log.Information("Application Started");

                AuthService authService = new AuthService();

                Console.WriteLine("===== Secure User Management System =====");
                Console.WriteLine("1. Register");
                Console.WriteLine("2. Login");
                Console.Write("Choose option (1 or 2): ");

                string choice = Console.ReadLine();

                Console.Write("Enter Username: ");
                string username = Console.ReadLine();

                Console.Write("Enter Password: ");
                string password = Console.ReadLine();

                if (choice == "1")
                {
                    bool registered = authService.Register(username, password);

                    if (registered)
                    {
                        Console.WriteLine("User Registered Successfully!");
                        Log.Information($"User registered: {username}");
                    }
                    else
                    {
                        Console.WriteLine("Registration Failed!");
                        Log.Warning($"Registration failed for user: {username}");
                    }
                }
                else if (choice == "2")
                {
                    bool loginSuccess = authService.Login(username, password);

                    if (loginSuccess)
                    {
                        Console.WriteLine("Login Successful!");
                        Log.Information($"User logged in: {username}");
                    }
                    else
                    {
                        Console.WriteLine("Login Failed!");
                        Log.Warning($"Failed login attempt for user: {username}");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Choice!");
                    Log.Warning("Invalid menu option selected.");
                }

                Log.Information("Application Finished Successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Something went wrong. Please try again later.");
                Log.Error(ex, "Unhandled exception occurred");
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }
    }
}