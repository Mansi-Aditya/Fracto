using Microsoft.VisualStudio.TestTools.UnitTesting;
using SolidDesignPatternsApp.DesignPatterns.Singleton;
using SolidDesignPatternsApp.DesignPatterns.Factory;
using SolidDesignPatternsApp.DesignPatterns.Observer;

namespace SolidDesignPatternsApp.Tests
{
    [TestClass]
    public class DesignPatternsTests
    {
        // Singleton Pattern
        [TestMethod]
        public void Logger_ShouldReturnSameInstance()
        {
            var logger1 = Logger.Instance;
            var logger2 = Logger.Instance;

            Assert.AreSame(logger1, logger2);
        }

        // Factory Pattern
        [TestMethod]
        public void DocumentFactory_ShouldCreateCorrectDocument()
        {
            var pdf = DocumentFactory.CreateDocument("PDF");
            var word = DocumentFactory.CreateDocument("WORD");

            Assert.IsInstanceOfType(pdf, typeof(PdfDocument));
            Assert.IsInstanceOfType(word, typeof(WordDocument));
        }

        // Factory Negative Case
        [TestMethod]
        public void DocumentFactory_ShouldThrowException_ForInvalidType()
        {
            Assert.ThrowsException<System.ArgumentException>(() =>
            {
                DocumentFactory.CreateDocument("INVALID");
            });
        }

        // Observer Pattern
        [TestMethod]
        public void WeatherStation_ShouldNotifyObservers()
        {
            var station = new WeatherStation();
            var observer = new TestWeatherObserver();

            station.Register(observer);
            station.SetTemperature(30);

            Assert.AreEqual(30, observer.LastTemperature);
        }

        // Helper Observer for testing
        private class TestWeatherObserver : IWeatherObserver
        {
            public float LastTemperature { get; private set; }

            public void Update(float temperature)
            {
                LastTemperature = temperature;
            }
        }
    }
}