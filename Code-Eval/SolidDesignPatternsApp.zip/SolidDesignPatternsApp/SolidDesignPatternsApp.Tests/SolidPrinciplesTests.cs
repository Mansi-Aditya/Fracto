using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using SolidDesignPatternsApp.SOLID.Interfaces;
using SolidDesignPatternsApp.SOLID.Services;
using SolidDesignPatternsApp.SOLID.Models;

namespace SolidDesignPatternsApp.Tests
{
    [TestClass]
    public class SolidPrinciplesTests
    {
        // SRP: ReportGenerator generates report
        [TestMethod]
        public void ReportGenerator_ShouldGenerateReport()
        {
            IReportGenerator generator = new ReportGenerator();

            string report = generator.GenerateReport();

            Assert.IsFalse(string.IsNullOrEmpty(report));
        }

        // OCP: Formatters interchangeable
        [TestMethod]
        public void Formatter_ShouldSupportPdfAndExcel()
        {
            IReportFormatter pdfFormatter = new PdfFormatter();
            IReportFormatter excelFormatter = new ExcelFormatter();

            string content = "Test Report";

            Assert.IsTrue(pdfFormatter.Format(content).Contains("PDF"));
            Assert.IsTrue(excelFormatter.Format(content).Contains("EXCEL"));
        }

        // LSP: Derived classes substitutable
        [TestMethod]
        public void DerivedReports_ShouldReplaceBaseReport()
        {
            Report salesReport = new SalesReport();
            Report inventoryReport = new InventoryReport();

            Assert.IsNotNull(salesReport.Generate());
            Assert.IsNotNull(inventoryReport.Generate());
        }

        // ISP: Printable report only prints
        [TestMethod]
        public void PrintableReport_ShouldPrintWithoutException()
        {
            IPrintableReport printable = new PrintableSalesReport();

            try
            {
                printable.Print();
                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception thrown: {ex.Message}");
            }
        }

        // DIP: High-level module depends on abstractions
        [TestMethod]
        public void ReportService_ShouldWorkWithInjectedDependencies()
        {
            var service = new ReportService(
                new ReportGenerator(),
                new ReportSaver(),
                new PdfFormatter());

            try
            {
                service.ProcessReport();
                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail($"Unexpected exception: {ex.Message}");
            }
        }
    }
}