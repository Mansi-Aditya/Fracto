namespace SolidDesignPatternsApp.DesignPatterns.Observer;

public interface IWeatherObserver
{
    void Update(float temperature);
}