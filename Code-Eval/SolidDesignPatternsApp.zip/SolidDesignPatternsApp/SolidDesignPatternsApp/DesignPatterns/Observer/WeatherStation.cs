namespace SolidDesignPatternsApp.DesignPatterns.Observer;

public class WeatherStation
{
    private readonly List<IWeatherObserver> _observers = new();
    private float _temperature;

    public void Register(IWeatherObserver observer) => _observers.Add(observer);
    public void Unregister(IWeatherObserver observer) => _observers.Remove(observer);

    public void SetTemperature(float temperature)
    {
        _temperature = temperature;
        Notify();
    }

    private void Notify()
    {
        foreach (var observer in _observers)
        {
            observer.Update(_temperature);
        }
    }
}