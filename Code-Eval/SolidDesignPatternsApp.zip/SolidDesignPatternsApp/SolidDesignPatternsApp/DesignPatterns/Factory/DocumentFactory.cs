namespace SolidDesignPatternsApp.DesignPatterns.Factory;

public class DocumentFactory
{
    public static IDocument CreateDocument(string type)
    {
        return type switch
        {
            "PDF" => new PdfDocument(),
            "WORD" => new WordDocument(),
            _ => throw new ArgumentException("Invalid document type")
        };
    }
}