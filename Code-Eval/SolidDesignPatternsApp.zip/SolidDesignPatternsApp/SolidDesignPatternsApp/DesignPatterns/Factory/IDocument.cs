namespace SolidDesignPatternsApp.DesignPatterns.Factory;

public interface IDocument
{
    void Open();
}