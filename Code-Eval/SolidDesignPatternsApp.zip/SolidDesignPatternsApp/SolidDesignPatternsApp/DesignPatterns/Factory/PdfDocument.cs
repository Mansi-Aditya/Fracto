namespace SolidDesignPatternsApp.DesignPatterns.Factory;

public class PdfDocument : IDocument
{
    public void Open() => Console.WriteLine("Opening PDF Document");
}

