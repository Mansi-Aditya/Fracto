namespace SolidDesignPatternsApp.SOLID.Interfaces;

public interface IPrintableReport
{
    void Print();
}
public class PrintableSalesReport : IPrintableReport
{
    public void Print()
    {
        Console.WriteLine("Printing Sales Report");
    }
}