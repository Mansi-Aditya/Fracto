namespace SolidDesignPatternsApp.SOLID.Interfaces;

public interface IReportGenerator
{
    string GenerateReport();
}

