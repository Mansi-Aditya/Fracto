namespace SolidDesignPatternsApp.SOLID.Interfaces;

public interface IReportSaver
{
    void Save(string reportContent);
}