namespace SolidDesignPatternsApp.SOLID.Interfaces;

public interface IReportFormatter
{
    string Format(string content);
}