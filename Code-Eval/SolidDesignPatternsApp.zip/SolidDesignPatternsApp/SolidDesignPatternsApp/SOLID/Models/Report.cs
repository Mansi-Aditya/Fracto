namespace SolidDesignPatternsApp.SOLID.Models;

public abstract class Report
{
    public abstract string Generate();
}
public class SalesReport : Report
{
    public override string Generate()
    {
        return "Sales Report Generated";
    }
}

public class InventoryReport : Report
{
    public override string Generate()
    {
        return "Inventory Report Generated";
    }
}