using SolidDesignPatternsApp.SOLID.Interfaces;

namespace SolidDesignPatternsApp.SOLID.Services;

public class ReportSaver : IReportSaver
{
    public void Save(string reportContent)
    {
        Console.WriteLine($"Report Saved: {reportContent}");
    }
}