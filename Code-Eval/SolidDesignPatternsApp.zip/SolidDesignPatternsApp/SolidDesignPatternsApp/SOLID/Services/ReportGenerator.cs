using SolidDesignPatternsApp.SOLID.Interfaces;

namespace SolidDesignPatternsApp.SOLID.Services;

public class ReportGenerator : IReportGenerator
{
    public string GenerateReport()
    {
        return "Report Content Generated";
    }
}

