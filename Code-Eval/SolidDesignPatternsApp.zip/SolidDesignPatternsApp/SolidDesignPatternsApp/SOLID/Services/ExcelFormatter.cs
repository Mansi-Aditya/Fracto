using SolidDesignPatternsApp.SOLID.Interfaces;

namespace SolidDesignPatternsApp.SOLID.Services;

public class ExcelFormatter : IReportFormatter
{
    public string Format(string content)
    {
        return $"[EXCEL FORMAT] {content}";
    }
}