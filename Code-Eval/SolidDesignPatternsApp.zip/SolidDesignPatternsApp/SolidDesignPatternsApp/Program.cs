﻿using SolidDesignPatternsApp.DesignPatterns.Factory;
using SolidDesignPatternsApp.DesignPatterns.Observer;
using SolidDesignPatternsApp.DesignPatterns.Singleton;
using SolidDesignPatternsApp.SOLID.Services;

class Program
{
    static void Main()
    {
        // SOLID Demo
        var service = new ReportService(
            new ReportGenerator(),
            new ReportSaver(),
            new PdfFormatter());

        service.ProcessReport();

        // Singleton
        Logger.Instance.Log("Singleton Logger Working");

        // Factory
        var doc = DocumentFactory.CreateDocument("PDF");
        doc.Open();

        // Observer
        var station = new WeatherStation();
        var display = new WeatherDisplay();

        station.Register(display);
        station.SetTemperature(30.5f);
    }
}