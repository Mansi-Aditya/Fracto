
# User Authentication - MongoDB Schema

## Collection: users

{
  _id: ObjectId,
  username: String,
  email: String,
  passwordHash: String,
  role: String,
  createdAt: Date
}

## Sample Document

{
  username: "john_doe",
  email: "john@example.com",
  passwordHash: "hashed_password_here",
  role: "customer",
  createdAt: new Date()
}
