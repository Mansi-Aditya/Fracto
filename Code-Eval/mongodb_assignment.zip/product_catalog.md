
# Product Catalog - MongoDB Schema

## Collection: products

{
  _id: ObjectId,
  name: String,
  description: String,
  category: String,
  price: Number,
  currency: String,
  stock: {
    available: Number,
    reserved: Number
  },
  attributes: {
    brand: String,
    color: String,
    size: String
  },
  images: [String],
  createdAt: Date,
  updatedAt: Date
}

## Sample Documents

{
  name: "iPhone 14",
  description: "Latest Apple smartphone",
  category: "Electronics",
  price: 999,
  currency: "USD",
  stock: { available: 50, reserved: 5 },
  attributes: { brand: "Apple", color: "Black", storage: "128GB" },
  images: ["img1.jpg"],
  createdAt: new Date(),
  updatedAt: new Date()
}

{
  name: "Men T-Shirt",
  description: "Cotton casual wear",
  category: "Clothing",
  price: 25,
  currency: "USD",
  stock: { available: 200, reserved: 10 },
  attributes: { brand: "Nike", color: "Blue", size: "L" },
  images: ["img2.jpg"],
  createdAt: new Date(),
  updatedAt: new Date()
}
