
# Customer Orders - MongoDB Schema

## Collection: orders

{
  _id: ObjectId,
  userId: ObjectId,
  orderDate: Date,
  status: String,
  products: [
    {
      productId: ObjectId,
      name: String,
      quantity: Number,
      price: Number
    }
  ],
  totalCost: Number,
  payment: {
    method: String,
    status: String,
    transactionId: String
  }
}

## Sample Document

{
  userId: ObjectId("123"),
  orderDate: new Date(),
  status: "Shipped",
  products: [
    { productId: ObjectId("p1"), name: "iPhone 14", quantity: 1, price: 999 },
    { productId: ObjectId("p2"), name: "T-Shirt", quantity: 2, price: 25 }
  ],
  totalCost: 1049,
  payment: { method: "Card", status: "Paid", transactionId: "txn123" }
}
