
# Querying and Indexing

## Proposed Indexes

1. Products Collection
db.products.createIndex({ category: 1 })
db.products.createIndex({ price: 1 })

2. Orders Collection
db.orders.createIndex({ userId: 1 })
db.orders.createIndex({ orderDate: -1 })

3. Users Collection
db.users.createIndex({ email: 1 }, { unique: true })

## Sample Queries

1. Retrieve products by category
db.products.find({ category: "Electronics" })

2. Retrieve products by price range
db.products.find({ price: { $gt: 100, $lt: 1000 } })

3. Find orders for a specific user
db.orders.find({ userId: ObjectId("123") })

4. Login query
db.users.findOne({ email: "john@example.com" })
